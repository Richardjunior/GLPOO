package Puzzle;

import javax.swing.JFrame;

import Puzzle.Jframe.PuzzleJFrame;

public class Launcher {

	public static void main(String[] args) {

		final JFrame frame = new PuzzleJFrame();
		frame.setVisible(true);
	}

}
